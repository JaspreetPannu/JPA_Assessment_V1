package com.fdmgroup.app;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.fdmgroup.model.Department;
import com.fdmgroup.model.Employee;
import com.fdmgroup.model.FullTimeEmployee;
import com.fdmgroup.model.PartTimeEmployee;

public class MainApp {
	public static void main(String[] args) {

		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("JPA_Assessment_1");
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		
		// Part 1 : Persist Departments
		
		entityManager.getTransaction().begin();
		
		Department d1 = new Department("Academy");
		Department d2 = new Department("Sales");
		
		//Part 2: Persist Employees
		
		FullTimeEmployee e1 = new FullTimeEmployee("John Doe", "Trainer", d1, 100000);
		FullTimeEmployee e2 = new FullTimeEmployee("Jane Doe", "Executive", d2, 120000);
		PartTimeEmployee e3 = new PartTimeEmployee("James Smith", "Trainer", d1, 80);
		
		d1.getEmployees().add(e1);
		d1.getEmployees().add(e3);
		d2.getEmployees().add(e2);
		
		entityManager.persist(d1);
		entityManager.persist(d2);
		
		entityManager.persist(e1);
		entityManager.persist(e2);
		entityManager.persist(e3);
		
		entityManager.getTransaction().commit();
		
		//Part 3: retrieve all employees from the Academy department
		
		List<Department> department = entityManager.createNamedQuery("department.findByDeptName", Department.class).setParameter("dname", "Academy").getResultList();
		
		System.out.println("*--------LIST OF EMPLOYEES IN ACADEMY DEPARTMENT--------*");
		
		if(department.size() == 1) {
			for(Employee e : department.get(0).getEmployees()) {
				System.out.println("\n " + e);
			}
		}
		
	}
}

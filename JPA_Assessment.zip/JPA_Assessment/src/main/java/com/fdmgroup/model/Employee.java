package com.fdmgroup.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "EMPLOYEE")
@Inheritance(strategy = InheritanceType.JOINED)
public class Employee {
	
	@Id
	@Column(name = "EMP_ID")
	@SequenceGenerator(name = "EMP_SEQ_GEN", sequenceName = "EMP_PK_SEQ", initialValue = 1, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "EMP_SEQ_GEN")
	private int empId;
	
	@Column(name = "EMP_NAME", nullable = false, updatable = false)
	private String empName;
	
	@Column(name = "EMP_DESIGNATION", nullable = false)
	private String empDesignation;
	
	@ManyToOne
	@JoinColumn(name = "FK_DEPT_D")
	private Department department;

	public Employee(String empName, String empDesignation, Department department) {
		super();
		this.empName = empName;
		this.empDesignation = empDesignation;
		this.department = department;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpDesignation() {
		return empDesignation;
	}

	public void setEmpDesignation(String empDesignation) {
		this.empDesignation = empDesignation;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empDesignation=" + empDesignation
				+ ", department=" + department + "]";
	}	
	
}

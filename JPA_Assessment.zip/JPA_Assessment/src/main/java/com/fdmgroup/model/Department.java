package com.fdmgroup.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "DEPARTMENT")
@NamedQueries({
	@NamedQuery(name = "department.findByDeptName", query = "SELECT d FROM Department d WHERE d.deptName = :dname")
})

public class Department {
	
	@Id
	@Column(name = "DEPT_ID")
	@SequenceGenerator(name = "DEPT_SEQ_GEN", sequenceName = "DEPT_PK_SEQ", initialValue = 1, allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DEPT_SEQ_GEN")
	private int deptId;

	@Column(name = "DEPT_NAME", unique = true, nullable = false)
	private String deptName;
	
	@OneToMany(mappedBy = "department")
	private List<Employee> employees;

	public Department(String deptName) {
		super();
		this.deptName = deptName;
		employees = new ArrayList<Employee>();
	}

	public int getDeptId() {
		return deptId;
	}

	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}

	@Override
	public String toString() {
		return "Department [deptId=" + deptId + ", deptName=" + deptName + "]";
	}

}
